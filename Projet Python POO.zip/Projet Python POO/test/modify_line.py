from fastapi.testclient import TestClient

from main import app

# Créez une instance de TestClient en utilisant votre application FastAPI
client = TestClient(app)

# Définition de la base url pour l'application FastAPI
base_url = "http://127.0.0.1:8012"

# Données à mettre à jour sous forme de JSON dans le corps de la requête
data = {
    "quantity": 4
}

# Index de l'item que vous voulez tester
id = 1

# Utilisez TestClient pour envoyer la requête PUT
response = client.put(f"/read_stock_data/update_stock_data/{id}", json=data)

# Assurez-vous que la réponse a un statut HTTP 200 OK
assert response.status_code == 200

# Utilisez response.json() pour obtenir le contenu de la réponse JSON
response_json = response.json()

# Print the response content
print(response_json)



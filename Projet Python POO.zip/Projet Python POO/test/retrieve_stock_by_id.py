import requests

# Définition de la base url pour l'application fastapi
base_url = "http://127.0.0.1:8012"

#index de l'item qu'on veut tester
id = 1

# envoi d'une requête GET au endpoint
response = requests.get(f"{base_url}/read_stock_data/items/{id}")

print(response.text)
import requests

# Définition de la base url pour l'application fastapi
base_url = "http://127.0.0.1:8012"

# Définition du query parameter qu'on veut tester
params = {
    "isin": "MSFT",
}

# envoi d'une requête GET au endpoint
response = requests.get(f"{base_url}/read_stock_data/items/", params=params)

# Check the response
if response.status_code == 200:
    result = response.json()
    print("Query result:")
    print(result)
else:
    print(f"Request failed with status code: {response.status_code}")
    print(response.text)
